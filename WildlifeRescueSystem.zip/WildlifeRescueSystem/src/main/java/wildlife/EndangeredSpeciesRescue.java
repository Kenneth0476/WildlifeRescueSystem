package wildlife;

/**
 * Rescue case for an endangered species.
 */
public class EndangeredSpeciesRescue extends RescueCase {

    private static final double SPECIALIST_TEAM_FEE = 8000.0;

    private String conservationClassification;
    private double securityCost;
    private boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(String rescueCaseId, String animalName, String species,
                                    String rescueLocation, String assignedRanger,
                                    int numberOfRescueDays, double dailyCareCost,
                                    String conservationClassification, double securityCost,
                                    boolean specialistTeamRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        this.conservationClassification = conservationClassification;
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = getBaseCareCost() + securityCost;
        if (specialistTeamRequired) {
            total += SPECIALIST_TEAM_FEE;
        }
        return total;
    }

    @Override
    public RescuePriority determinePriority() {
        String classification = conservationClassification == null
                ? "" : conservationClassification.trim().toLowerCase();

        if (classification.contains("critically")) {
            return RescuePriority.CRITICAL;
        }
        if (classification.contains("endangered") || specialistTeamRequired) {
            return RescuePriority.HIGH;
        }
        return RescuePriority.MEDIUM;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public void displaySpecificInfo() {
        System.out.println("Conservation Classification : " + conservationClassification);
        System.out.printf("Security Cost               : R%.2f%n", securityCost);
        System.out.println("Specialist Team Required    : " + (specialistTeamRequired ? "Yes" : "No"));
    }

    public String getConservationClassification() {
        return conservationClassification;
    }

    public void setConservationClassification(String conservationClassification) {
        this.conservationClassification = conservationClassification;
    }

    public double getSecurityCost() {
        return securityCost;
    }

    public void setSecurityCost(double securityCost) {
        this.securityCost = securityCost;
    }

    public boolean isSpecialistTeamRequired() {
        return specialistTeamRequired;
    }

    public void setSpecialistTeamRequired(boolean specialistTeamRequired) {
        this.specialistTeamRequired = specialistTeamRequired;
    }
}
