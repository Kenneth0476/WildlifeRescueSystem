package wildlife;

/**
 * Rescue case for an injured animal.
 * Overrides the abstract methods from RescueCase (method overriding).
 */
public class InjuredAnimalRescue extends RescueCase {

    private static final double SURGERY_FEE = 5000.0;
    private static final double HIGH_TREATMENT_COST_THRESHOLD = 10000.0;

    private String injuryDescription;
    private double veterinaryTreatmentCost;
    private boolean surgeryRequired;

    public InjuredAnimalRescue(String rescueCaseId, String animalName, String species,
                                String rescueLocation, String assignedRanger,
                                int numberOfRescueDays, double dailyCareCost,
                                String injuryDescription, double veterinaryTreatmentCost,
                                boolean surgeryRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        this.injuryDescription = injuryDescription;
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = getBaseCareCost() + veterinaryTreatmentCost;
        if (surgeryRequired) {
            total += SURGERY_FEE;
        }
        return total;
    }

    @Override
    public RescuePriority determinePriority() {
        if (surgeryRequired) {
            return RescuePriority.CRITICAL;
        }
        if (veterinaryTreatmentCost > HIGH_TREATMENT_COST_THRESHOLD) {
            return RescuePriority.HIGH;
        }
        return RescuePriority.MEDIUM;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public void displaySpecificInfo() {
        System.out.println("Injury Description        : " + injuryDescription);
        System.out.printf("Veterinary Treatment Cost  : R%.2f%n", veterinaryTreatmentCost);
        System.out.println("Surgery Required           : " + (surgeryRequired ? "Yes" : "No"));
    }

    public String getInjuryDescription() {
        return injuryDescription;
    }

    public void setInjuryDescription(String injuryDescription) {
        this.injuryDescription = injuryDescription;
    }

    public double getVeterinaryTreatmentCost() {
        return veterinaryTreatmentCost;
    }

    public void setVeterinaryTreatmentCost(double veterinaryTreatmentCost) {
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
    }

    public boolean isSurgeryRequired() {
        return surgeryRequired;
    }

    public void setSurgeryRequired(boolean surgeryRequired) {
        this.surgeryRequired = surgeryRequired;
    }
}
