package wildlife;

import java.util.List;
import java.util.Scanner;

/**
 * Console entry point for the Wildlife Rescue Operations System.
 *
 * NOTE FOR SUBMISSION: this file was produced with AI assistance
 * (Claude) for the class structure and console flow; go through it,
 * make sure you understand every method, and adjust anything you'd
 * naturally write differently before submitting - see PROG6112 PA2
 * instruction 4 on disclosing AI use.
 */
public class Main {

    private static final Scanner sc = new Scanner(System.in);
    private static final RescueCaseManager manager = new RescueCaseManager();

    public static void main(String[] args) {
        int choice;
        do {
            printMenu();
            choice = readMenuChoice(1, 6);

            switch (choice) {
                case 1 -> createRescueCase();
                case 2 -> searchRescueCase();
                case 3 -> updateRescueStatus();
                case 4 -> displayAllCases();
                case 5 -> rescueReport();
                case 6 -> System.out.println("Exiting Wildlife Rescue Operations System. Goodbye!");
            }
        } while (choice != 6);

        sc.close();
    }

    // ---------------------------------------------------------------
    // Menu
    // ---------------------------------------------------------------

    private static void printMenu() {
        System.out.println();
        System.out.println("====================================");
        System.out.println("WILDLIFE RESCUE OPERATIONS SYSTEM");
        System.out.println("====================================");
        System.out.println();
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Rescue Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
        System.out.println();
    }

    // ---------------------------------------------------------------
    // 1. Create Rescue Case
    // ---------------------------------------------------------------

    private static void createRescueCase() {
        System.out.println("\n--- Create Rescue Case ---");

        String rescueCaseId;
        do {
            rescueCaseId = readNonBlank("Rescue Case ID: ");
            if (manager.isIdTaken(rescueCaseId)) {
                System.out.println("That Rescue Case ID is already in use. Please enter a different one.");
                rescueCaseId = "";
            }
        } while (rescueCaseId.isEmpty());

        String animalName = readNonBlank("Animal Name: ");
        String species = readNonBlank("Species: ");
        String rescueLocation = readNonBlank("Rescue Location: ");
        String assignedRanger = readNonBlank("Assigned Ranger: ");
        int numberOfRescueDays = readPositiveInt("Number of Rescue Days: ");
        double dailyCareCost = readPositiveDouble("Daily Care Cost (R): ");

        System.out.println("\nSelect Rescue Case Type:");
        System.out.println("1. Injured Animal Rescue");
        System.out.println("2. Orphaned Animal Rescue");
        System.out.println("3. Endangered Species Rescue");
        int typeChoice = readMenuChoice(1, 3);

        RescueCase rescueCase = switch (typeChoice) {
            case 1 -> buildInjuredAnimalRescue(rescueCaseId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
            case 2 -> buildOrphanedAnimalRescue(rescueCaseId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
            default -> buildEndangeredSpeciesRescue(rescueCaseId, animalName, species,
                    rescueLocation, assignedRanger, numberOfRescueDays, dailyCareCost);
        };

        if (manager.addRescueCase(rescueCase)) {
            System.out.println("\nRescue case " + rescueCaseId + " created successfully.");
        } else {
            System.out.println("\nCould not create rescue case (duplicate or invalid ID).");
        }
    }

    private static InjuredAnimalRescue buildInjuredAnimalRescue(String id, String animalName,
            String species, String location, String ranger, int days, double dailyCost) {
        String injuryDescription = readNonBlank("Injury Description: ");
        double vetCost = readPositiveDouble("Veterinary Treatment Cost (R): ");
        boolean surgeryRequired = readYesNo("Surgery Required? (Y/N): ");
        return new InjuredAnimalRescue(id, animalName, species, location, ranger, days, dailyCost,
                injuryDescription, vetCost, surgeryRequired);
    }

    private static OrphanedAnimalRescue buildOrphanedAnimalRescue(String id, String animalName,
            String species, String location, String ranger, int days, double dailyCost) {
        int ageMonths = readPositiveInt("Estimated Age (Months): ");
        double feedingCost = readPositiveDouble("Feeding Cost (R): ");
        boolean fosterCareRequired = readYesNo("Foster Care Required? (Y/N): ");
        return new OrphanedAnimalRescue(id, animalName, species, location, ranger, days, dailyCost,
                ageMonths, feedingCost, fosterCareRequired);
    }

    private static EndangeredSpeciesRescue buildEndangeredSpeciesRescue(String id, String animalName,
            String species, String location, String ranger, int days, double dailyCost) {
        String classification = readNonBlank("Conservation Classification: ");
        double securityCost = readPositiveDouble("Security Cost (R): ");
        boolean specialistTeamRequired = readYesNo("Specialist Team Required? (Y/N): ");
        return new EndangeredSpeciesRescue(id, animalName, species, location, ranger, days, dailyCost,
                classification, securityCost, specialistTeamRequired);
    }

    // ---------------------------------------------------------------
    // 2. Search Rescue Case
    // ---------------------------------------------------------------

    private static void searchRescueCase() {
        System.out.println("\n--- Search Rescue Case ---");
        String id = readNonBlank("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findById(id);

        if (rescueCase == null) {
            System.out.println("No rescue case found with ID: " + id);
            return;
        }

        System.out.println();
        System.out.print(rescueCase.generateRescueSummary());
        rescueCase.displaySpecificInfo();
    }

    // ---------------------------------------------------------------
    // 3. Update Rescue Status
    // ---------------------------------------------------------------

    private static void updateRescueStatus() {
        System.out.println("\n--- Update Rescue Status ---");
        String id = readNonBlank("Enter Rescue Case ID: ");
        RescueCase rescueCase = manager.findById(id);

        if (rescueCase == null) {
            System.out.println("No rescue case found with ID: " + id);
            return;
        }

        System.out.println("Current Status: " + rescueCase.getCurrentStatus());
        System.out.println("1. Start Rescue");
        System.out.println("2. Place Under Observation");
        System.out.println("3. Complete Rescue");
        int choice = readMenuChoice(1, 3);

        switch (choice) {
            case 1 -> rescueCase.startRescue();
            case 2 -> rescueCase.placeUnderObservation();
            case 3 -> rescueCase.completeRescue();
        }

        System.out.println("Status updated to: " + rescueCase.getCurrentStatus());
    }

    // ---------------------------------------------------------------
    // 4. Display All Rescue Cases
    // ---------------------------------------------------------------

    private static void displayAllCases() {
        System.out.println("\n--- All Rescue Cases ---");
        List<RescueCase> cases = manager.getAllCases();

        if (cases.isEmpty()) {
            System.out.println("No rescue cases recorded yet.");
            return;
        }

        for (RescueCase rc : cases) {
            System.out.println();
            System.out.print(rc.generateRescueSummary());
            rc.displaySpecificInfo();
            System.out.println("----------------------------------------------------");
        }
    }

    // ---------------------------------------------------------------
    // 5. Rescue Report
    // ---------------------------------------------------------------

    private static void rescueReport() {
        System.out.println();
        System.out.print(manager.generateReport());
    }

    // ---------------------------------------------------------------
    // Input validation helpers
    // ---------------------------------------------------------------

    private static String readNonBlank(String prompt) {
        String value;
        do {
            System.out.print(prompt);
            value = sc.nextLine().trim();
            if (value.isEmpty()) {
                System.out.println("This field cannot be blank. Please try again.");
            }
        } while (value.isEmpty());
        return value;
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a whole number greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim();
            try {
                double value = Double.parseDouble(input);
                if (value > 0) {
                    return value;
                }
                System.out.println("Please enter a number greater than zero.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }

    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = sc.nextLine().trim().toUpperCase();
            if (input.equals("Y")) {
                return true;
            }
            if (input.equals("N")) {
                return false;
            }
            System.out.println("Please enter Y or N.");
        }
    }

    private static int readMenuChoice(int min, int max) {
        while (true) {
            System.out.print("Select an option: ");
            String input = sc.nextLine().trim();
            try {
                int value = Integer.parseInt(input);
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("Please enter a number between " + min + " and " + max + ".");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
            }
        }
    }
}
