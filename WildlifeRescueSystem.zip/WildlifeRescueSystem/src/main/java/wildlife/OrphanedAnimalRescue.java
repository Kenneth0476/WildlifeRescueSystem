package wildlife;

/**
 * Rescue case for an orphaned animal.
 */
public class OrphanedAnimalRescue extends RescueCase {

    private static final double FOSTER_CARE_FEE = 2500.0;
    private static final int VERY_YOUNG_AGE_MONTHS = 2;
    private static final int YOUNG_AGE_MONTHS = 6;

    private int estimatedAgeMonths;
    private double feedingCost;
    private boolean fosterCareRequired;

    public OrphanedAnimalRescue(String rescueCaseId, String animalName, String species,
                                 String rescueLocation, String assignedRanger,
                                 int numberOfRescueDays, double dailyCareCost,
                                 int estimatedAgeMonths, double feedingCost,
                                 boolean fosterCareRequired) {
        super(rescueCaseId, animalName, species, rescueLocation, assignedRanger,
                numberOfRescueDays, dailyCareCost);
        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public double calculateTotalCost() {
        double total = getBaseCareCost() + feedingCost;
        if (fosterCareRequired) {
            total += FOSTER_CARE_FEE;
        }
        return total;
    }

    @Override
    public RescuePriority determinePriority() {
        if (estimatedAgeMonths <= VERY_YOUNG_AGE_MONTHS) {
            return RescuePriority.CRITICAL;
        }
        if (estimatedAgeMonths <= YOUNG_AGE_MONTHS || fosterCareRequired) {
            return RescuePriority.HIGH;
        }
        return RescuePriority.MEDIUM;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public void displaySpecificInfo() {
        System.out.println("Estimated Age (Months)     : " + estimatedAgeMonths);
        System.out.printf("Feeding Cost               : R%.2f%n", feedingCost);
        System.out.println("Foster Care Required       : " + (fosterCareRequired ? "Yes" : "No"));
    }

    public int getEstimatedAgeMonths() {
        return estimatedAgeMonths;
    }

    public void setEstimatedAgeMonths(int estimatedAgeMonths) {
        this.estimatedAgeMonths = estimatedAgeMonths;
    }

    public double getFeedingCost() {
        return feedingCost;
    }

    public void setFeedingCost(double feedingCost) {
        this.feedingCost = feedingCost;
    }

    public boolean isFosterCareRequired() {
        return fosterCareRequired;
    }

    public void setFosterCareRequired(boolean fosterCareRequired) {
        this.fosterCareRequired = fosterCareRequired;
    }
}
