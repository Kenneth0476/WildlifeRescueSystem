package wildlife;

import java.util.Locale;

/**
 * Abstract base class for every wildlife rescue case.
 *
 * Demonstrates:
 *  - Encapsulation: all fields are private, accessed only via getters/setters.
 *  - Abstraction: calculateTotalCost(), determinePriority(), getRescueType()
 *    and displaySpecificInfo() are declared here but have no shared
 *    implementation - each concrete rescue type MUST provide its own.
 *  - Inheritance: InjuredAnimalRescue, OrphanedAnimalRescue and
 *    EndangeredSpeciesRescue all extend this class and reuse the common
 *    fields/behaviour (ID, ranger, status, base cost, etc.).
 */
public abstract class RescueCase implements RescueOperations {

    private final String rescueCaseId;
    private String animalName;
    private String species;
    private String rescueLocation;
    private String assignedRanger;
    private int numberOfRescueDays;
    private double dailyCareCost;
    private RescueStatus currentStatus;

    protected RescueCase(String rescueCaseId, String animalName, String species,
                          String rescueLocation, String assignedRanger,
                          int numberOfRescueDays, double dailyCareCost) {
        this.rescueCaseId = rescueCaseId;
        this.animalName = animalName;
        this.species = species;
        this.rescueLocation = rescueLocation;
        this.assignedRanger = assignedRanger;
        this.numberOfRescueDays = numberOfRescueDays;
        this.dailyCareCost = dailyCareCost;
        this.currentStatus = RescueStatus.REPORTED;
    }

    // ---------- Abstract methods every subclass must implement ----------

    /** Total cost for this rescue case, including type-specific costs. */
    public abstract double calculateTotalCost();

    /** Priority level, worked out from this rescue type's own rules. */
    public abstract RescuePriority determinePriority();

    /** A short label such as "Injured Animal Rescue". */
    public abstract String getRescueType();

    /** Prints the fields that are specific to this rescue type. */
    public abstract void displaySpecificInfo();

    // ---------- Shared helper for subclasses ----------

    /** Base care cost common to every rescue type: days * daily cost. */
    protected double getBaseCareCost() {
        return numberOfRescueDays * dailyCareCost;
    }

    // ---------- RescueOperations implementation (shared behaviour) ----------

    @Override
    public void startRescue() {
        this.currentStatus = RescueStatus.RESCUE_IN_PROGRESS;
    }

    @Override
    public void completeRescue() {
        this.currentStatus = RescueStatus.RESCUE_COMPLETED;
    }

    /** Marks a case as being monitored rather than actively rescued. */
    public void placeUnderObservation() {
        this.currentStatus = RescueStatus.UNDER_OBSERVATION;
    }

    @Override
    public String generateRescueSummary() {
        return String.format(Locale.US,
                "Rescue Case ID  : %s%n" +
                "Rescue Type     : %s%n" +
                "Species         : %s%n" +
                "Assigned Ranger : %s%n" +
                "Rescue Priority : %s%n" +
                "Current Status  : %s%n" +
                "Total Rescue Cost: R%.2f%n",
                rescueCaseId, getRescueType(), species, assignedRanger,
                determinePriority(), currentStatus, calculateTotalCost());
    }

    // ---------- Getters / setters (encapsulation) ----------

    public String getRescueCaseId() {
        return rescueCaseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public void setAnimalName(String animalName) {
        this.animalName = animalName;
    }

    public String getSpecies() {
        return species;
    }

    public void setSpecies(String species) {
        this.species = species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public void setRescueLocation(String rescueLocation) {
        this.rescueLocation = rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public void setAssignedRanger(String assignedRanger) {
        this.assignedRanger = assignedRanger;
    }

    public int getNumberOfRescueDays() {
        return numberOfRescueDays;
    }

    public void setNumberOfRescueDays(int numberOfRescueDays) {
        this.numberOfRescueDays = numberOfRescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public void setDailyCareCost(double dailyCareCost) {
        this.dailyCareCost = dailyCareCost;
    }

    public RescueStatus getCurrentStatus() {
        return currentStatus;
    }

    public void setCurrentStatus(RescueStatus currentStatus) {
        this.currentStatus = currentStatus;
    }
}
