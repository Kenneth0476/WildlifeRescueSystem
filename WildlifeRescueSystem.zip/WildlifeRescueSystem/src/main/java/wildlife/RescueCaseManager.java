package wildlife;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Holds all rescue cases in an ArrayList and provides the operations
 * the menu needs: add, search, list, and reporting.
 *
 * Kept separate from Main (the console UI) on purpose, so the logic
 * can be unit tested without needing to simulate keyboard input.
 */
public class RescueCaseManager {

    private final List<RescueCase> rescueCases = new ArrayList<>();

    /**
     * Adds a rescue case, rejecting it if the ID is blank or already used.
     * @return true if added, false if the ID was blank or a duplicate.
     */
    public boolean addRescueCase(RescueCase rescueCase) {
        if (rescueCase == null) {
            return false;
        }
        String id = rescueCase.getRescueCaseId();
        if (id == null || id.trim().isEmpty()) {
            return false;
        }
        if (findById(id) != null) {
            return false;
        }
        rescueCases.add(rescueCase);
        return true;
    }

    /** Case-insensitive search by Rescue Case ID. Returns null if not found. */
    public RescueCase findById(String rescueCaseId) {
        if (rescueCaseId == null) {
            return null;
        }
        for (RescueCase rc : rescueCases) {
            if (rc.getRescueCaseId().equalsIgnoreCase(rescueCaseId.trim())) {
                return rc;
            }
        }
        return null;
    }

    public boolean isIdTaken(String rescueCaseId) {
        return findById(rescueCaseId) != null;
    }

    public List<RescueCase> getAllCases() {
        return rescueCases;
    }

    public int getCaseCount() {
        return rescueCases.size();
    }

    public double getTotalRescueCost() {
        double total = 0;
        for (RescueCase rc : rescueCases) {
            total += rc.calculateTotalCost();
        }
        return total;
    }

    /** Builds the full "Wildlife Rescue Report" text. */
    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("====================================================\n");
        sb.append("WILDLIFE RESCUE REPORT\n");
        sb.append("====================================================\n\n");

        if (rescueCases.isEmpty()) {
            sb.append("No rescue cases have been recorded yet.\n\n");
        }

        for (RescueCase rc : rescueCases) {
            sb.append(String.format(Locale.US,
                    "Case ID     : %s%n" +
                    "Type        : %s%n" +
                    "Species     : %s%n" +
                    "Location    : %s%n" +
                    "Ranger      : %s%n" +
                    "Priority    : %s%n" +
                    "Status      : %s%n" +
                    "Total Cost  : R%.2f%n",
                    rc.getRescueCaseId(), rc.getRescueType(), rc.getSpecies(),
                    rc.getRescueLocation(), rc.getAssignedRanger(), rc.determinePriority(),
                    rc.getCurrentStatus(), rc.calculateTotalCost()));
            sb.append("----------------------------------------------------\n\n");
        }

        sb.append(String.format(Locale.US, "Total Rescue Cases : %d%n", getCaseCount()));
        sb.append(String.format(Locale.US, "Total Rescue Cost  : R%.2f%n", getTotalRescueCost()));
        return sb.toString();
    }
}
