package wildlife;

/**
 * Interface satisfying the "Rescue Operations" requirement.
 * Every rescue case type must be able to start, complete and summarise
 * itself. Because Main and RescueCaseManager work with this interface
 * (not the concrete subclasses), calling these methods on a mixed list
 * of rescue cases demonstrates polymorphism.
 */
public interface RescueOperations {

    void startRescue();

    void completeRescue();

    String generateRescueSummary();
}
