package wildlife;

/**
 * Priority level of a rescue case. Each RescueCase subclass decides
 * its own priority in determinePriority() - this is where the
 * assignment's "each type determines an appropriate priority" requirement lives.
 */
public enum RescuePriority {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}
