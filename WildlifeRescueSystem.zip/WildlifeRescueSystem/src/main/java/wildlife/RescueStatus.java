package wildlife;

/**
 * Represents the lifecycle status of a rescue case.
 * Using an enum (instead of a plain String) stops invalid/typo'd
 * status values from ever being stored - this is a form of encapsulation.
 */
public enum RescueStatus {
    REPORTED("Reported"),
    RESCUE_IN_PROGRESS("Rescue in Progress"),
    UNDER_OBSERVATION("Under Observation"),
    RESCUE_COMPLETED("Rescue Completed");

    private final String displayLabel;

    RescueStatus(String displayLabel) {
        this.displayLabel = displayLabel;
    }

    @Override
    public String toString() {
        return displayLabel;
    }
}
