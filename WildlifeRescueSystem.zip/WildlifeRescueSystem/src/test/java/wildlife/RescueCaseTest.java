package wildlife;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Core unit tests for the Wildlife Rescue Operations System.
 * Covers: cost calculations, priority calculations, status updates,
 * searching, and duplicate Rescue Case ID prevention.
 */
class RescueCaseTest {

    private RescueCaseManager manager;

    @BeforeEach
    void setUp() {
        manager = new RescueCaseManager();
    }

    // ----------------- Cost calculations -----------------

    @Test
    void injuredRescue_totalCost_includesSurgeryFeeWhenRequired() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR101", "Tembo", "African Elephant", "Kruger", "Ranger Naledi",
                5, 1000.0, "Broken tusk", 8000.0, true);

        // 5 * 1000 (care) + 8000 (vet) + 5000 (surgery) = 18000
        assertEquals(18000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void injuredRescue_totalCost_excludesSurgeryFeeWhenNotRequired() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR102", "Simba", "Lion", "Kruger", "Ranger Naledi",
                3, 500.0, "Minor cut", 1000.0, false);

        // 3 * 500 + 1000 = 2500
        assertEquals(2500.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void orphanedRescue_totalCost_includesFosterCareFeeWhenRequired() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR201", "Thabo", "White Rhino", "Pilanesberg", "Ranger Sipho",
                10, 200.0, 2, 1500.0, true);

        // 10 * 200 + 1500 + 2500 = 6000
        assertEquals(6000.0, rescue.calculateTotalCost(), 0.001);
    }

    @Test
    void endangeredRescue_totalCost_includesSpecialistTeamFeeWhenRequired() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR301", "Nkosi", "Black Rhino", "Kruger", "Ranger Naledi",
                7, 300.0, "Critically Endangered", 4000.0, true);

        // 7 * 300 + 4000 + 8000 = 14100
        assertEquals(14100.0, rescue.calculateTotalCost(), 0.001);
    }

    // ----------------- Priority calculations -----------------

    @Test
    void injuredRescue_priority_isCriticalWhenSurgeryRequired() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR103", "Duma", "Cheetah", "Kruger", "Ranger Naledi",
                4, 500.0, "Fractured leg", 3000.0, true);

        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    @Test
    void orphanedRescue_priority_isCriticalForVeryYoungAnimal() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR202", "Kito", "Elephant Calf", "Addo", "Ranger Sipho",
                14, 400.0, 1, 2000.0, false);

        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    @Test
    void endangeredRescue_priority_isCriticalForCriticallyEndangeredClassification() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR302", "Zola", "Pangolin", "Limpopo", "Ranger Naledi",
                6, 250.0, "Critically Endangered", 1500.0, false);

        assertEquals(RescuePriority.CRITICAL, rescue.determinePriority());
    }

    // ----------------- Status updates -----------------

    @Test
    void startRescue_setsStatusToRescueInProgress() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR104", "Sifiso", "Buffalo", "Kruger", "Ranger Naledi",
                2, 300.0, "Gunshot wound", 5000.0, true);

        rescue.startRescue();

        assertEquals(RescueStatus.RESCUE_IN_PROGRESS, rescue.getCurrentStatus());
    }

    @Test
    void completeRescue_setsStatusToRescueCompleted() {
        OrphanedAnimalRescue rescue = new OrphanedAnimalRescue(
                "WR203", "Amara", "Giraffe", "Addo", "Ranger Sipho",
                8, 350.0, 5, 1200.0, false);

        rescue.startRescue();
        rescue.completeRescue();

        assertEquals(RescueStatus.RESCUE_COMPLETED, rescue.getCurrentStatus());
    }

    // ----------------- Search -----------------

    @Test
    void findById_returnsMatchingCase() {
        EndangeredSpeciesRescue rescue = new EndangeredSpeciesRescue(
                "WR303", "Themba", "White Lion", "Timbavati", "Ranger Naledi",
                9, 450.0, "Vulnerable", 2200.0, false);
        manager.addRescueCase(rescue);

        RescueCase found = manager.findById("WR303");

        assertNotNull(found);
        assertEquals("Themba", found.getAnimalName());
    }

    @Test
    void findById_returnsNullWhenCaseDoesNotExist() {
        assertNull(manager.findById("DOES_NOT_EXIST"));
    }

    // ----------------- Duplicate ID prevention -----------------

    @Test
    void addRescueCase_rejectsDuplicateRescueCaseId() {
        InjuredAnimalRescue first = new InjuredAnimalRescue(
                "WR105", "Lindiwe", "Zebra", "Kruger", "Ranger Naledi",
                3, 300.0, "Sprained leg", 900.0, false);
        InjuredAnimalRescue duplicate = new InjuredAnimalRescue(
                "WR105", "Different Animal", "Zebra", "Kruger", "Ranger Sipho",
                1, 100.0, "Different injury", 100.0, false);

        assertTrue(manager.addRescueCase(first));
        assertFalse(manager.addRescueCase(duplicate));
        assertEquals(1, manager.getCaseCount());
    }
}
